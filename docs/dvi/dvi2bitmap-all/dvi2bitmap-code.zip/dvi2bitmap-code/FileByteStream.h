/* This file is part of dvi2bitmap; see README for copyrights and licence */

#ifndef FILE_BYTE_STREAM_HEADER_READ
#define FILE_BYTE_STREAM_HEADER_READ 1

#include <InputByteStream.h>

/** An input file. */
class FileByteStream : public InputByteStream {

 public:
    FileByteStream(string& filename,
		   string tryext="",
		   bool preload=false)
	    throw (InputByteStreamError);
    ~FileByteStream();
    void seek(int pos)
	    throw (InputByteStreamError);    

 private:
    int filesize_;
};

#endif	/* FILE_BYTE_STREAM_HEADER_READ */
