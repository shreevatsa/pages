/* This file is part of dvi2bitmap; see README for copyrights and licence */

#ifndef BYTE_HEADER_READ
#define BYTE_HEADER_READ 1

// I believe this to be the only machine-dependent bit, since in
// principle a byte could be different from an unsigned char on some
// odd platforms.  We don't even have to worry about bytesex.
typedef unsigned char Byte;

#endif // #ifdef BYTE_HEADER_READ
