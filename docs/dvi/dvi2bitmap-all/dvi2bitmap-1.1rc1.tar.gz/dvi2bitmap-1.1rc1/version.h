const char version_string[] = "dvi2bitmap version 1.1rc1, 2017 April 09";
